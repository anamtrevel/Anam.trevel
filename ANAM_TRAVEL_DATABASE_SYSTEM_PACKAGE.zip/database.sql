-- ANAM TRAVEL database schema (SQLite/MySQL-friendly)
CREATE TABLE IF NOT EXISTS customers (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name VARCHAR(120) NOT NULL,
 mobile VARCHAR(30) NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS vehicles (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name VARCHAR(80) NOT NULL,
 registration VARCHAR(40),
 vehicle_type VARCHAR(40) NOT NULL,
 round_trip_rate DECIMAL(10,2) NOT NULL,
 active INTEGER DEFAULT 1
);
CREATE TABLE IF NOT EXISTS bookings (
 id VARCHAR(30) PRIMARY KEY,
 customer_id INTEGER,
 trip_type VARCHAR(30) NOT NULL,
 vehicle_id INTEGER,
 pickup VARCHAR(255) NOT NULL,
 drop_location VARCHAR(255) NOT NULL,
 travel_date DATE NOT NULL,
 travel_time TIME,
 distance_km DECIMAL(10,2),
 rental_package VARCHAR(40),
 estimated_fare DECIMAL(10,2),
 advance_type VARCHAR(30),
 status VARCHAR(30) DEFAULT 'Inquiry',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(customer_id) REFERENCES customers(id),
 FOREIGN KEY(vehicle_id) REFERENCES vehicles(id)
);
CREATE TABLE IF NOT EXISTS drivers (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name VARCHAR(120) NOT NULL,
 mobile VARCHAR(30),
 active INTEGER DEFAULT 1
);
CREATE TABLE IF NOT EXISTS duties (
 id VARCHAR(30) PRIMARY KEY,
 booking_id VARCHAR(30),
 driver_id INTEGER,
 vehicle_id INTEGER,
 duty_date DATE NOT NULL,
 duty_time TIME,
 pickup VARCHAR(255) NOT NULL,
 drop_location VARCHAR(255) NOT NULL,
 status VARCHAR(30) DEFAULT 'New Duty',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(booking_id) REFERENCES bookings(id),
 FOREIGN KEY(driver_id) REFERENCES drivers(id),
 FOREIGN KEY(vehicle_id) REFERENCES vehicles(id)
);
CREATE TABLE IF NOT EXISTS payments (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 booking_id VARCHAR(30) NOT NULL,
 amount DECIMAL(10,2) NOT NULL,
 method VARCHAR(30),
 status VARCHAR(30) DEFAULT 'Pending',
 paid_at TIMESTAMP,
 FOREIGN KEY(booking_id) REFERENCES bookings(id)
);
CREATE TABLE IF NOT EXISTS feedback (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 booking_id VARCHAR(30),
 customer_name VARCHAR(120),
 rating INTEGER CHECK(rating BETWEEN 1 AND 5),
 feedback_text TEXT,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(booking_id) REFERENCES bookings(id)
);
CREATE TABLE IF NOT EXISTS notifications (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 role VARCHAR(30),
 user_id INTEGER,
 message TEXT NOT NULL,
 is_read INTEGER DEFAULT 0,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Default ANAM TRAVEL rates
INSERT INTO vehicles(name,registration,vehicle_type,round_trip_rate) VALUES
('Sedan','', 'Sedan',13),
('SUV','', 'SUV',16),
('6+1 SUV','', '6+1 SUV',22);

-- Rental packages: 4/40=1200, 8/80=2400, 10/100=3000, 12/120=3600
-- Driver allowance: ₹250 for one night. Parking extra. Other taxes/charges follow the booking terms.
